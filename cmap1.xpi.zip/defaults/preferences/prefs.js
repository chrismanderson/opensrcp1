pref("extensions.cmap1.boolpref", false);
pref("extensions.cmap1.intpref", 0);
pref("extensions.cmap1.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.christopher.anderson@gmail.com.description", "chrome://cmap1/locale/overlay.properties");
